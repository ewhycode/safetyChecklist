
import React from 'react';
import { RiskLevel } from '../types';

const LIKELIHOOD = ['Rare', 'Unlikely', 'Possible', 'Likely', 'Almost Certain'];
const CONSEQUENCE = ['Insignificant', 'Minor', 'Moderate', 'Major', 'Catastrophic'];

// This matrix determines the risk level. A simple multiplication approach.
// 1-4: Low, 5-9: Medium, 10-15: High, 16-25: Extreme
const getRiskLevel = (likelihood: number, consequence: number): RiskLevel => {
  const score = (likelihood + 1) * (consequence + 1);
  if (score <= 4) return RiskLevel.Low;
  if (score <= 9) return RiskLevel.Medium;
  if (score <= 15) return RiskLevel.High;
  return RiskLevel.Extreme;
};

const riskLevelColors: Record<RiskLevel, string> = {
  [RiskLevel.Low]: 'bg-emerald-500',
  [RiskLevel.Medium]: 'bg-yellow-500',
  [RiskLevel.High]: 'bg-orange-500',
  [RiskLevel.Extreme]: 'bg-rose-600',
  [RiskLevel.Unknown]: 'bg-slate-400',
};

interface RiskMatrixProps {
  likelihood: number; // 0-4
  consequence: number; // 0-4
  onRiskChange: (likelihood: number, consequence: number) => void;
  readOnly?: boolean;
}

const RiskMatrix: React.FC<RiskMatrixProps> = ({ likelihood, consequence, onRiskChange, readOnly = false }) => {

  const handleCellClick = (lIndex: number, cIndex: number) => {
    if (!readOnly) {
      onRiskChange(lIndex, cIndex);
    }
  };
  
  const currentRiskLevel = getRiskLevel(likelihood, consequence);

  return (
    <div>
      <div className="grid grid-cols-6 gap-1">
        <div className="font-bold text-xs flex items-end justify-center rotate-[-45deg] translate-y-8 -translate-x-2">Likelihood</div>
        {CONSEQUENCE.map((c, i) => (
          <div key={i} className="font-bold text-center text-xs sm:text-sm">{c}</div>
        ))}

        {LIKELIHOOD.map((l, lIndex) => (
          <React.Fragment key={lIndex}>
            <div className="font-bold text-right text-xs sm:text-sm flex items-center justify-end pr-2">{l}</div>
            {CONSEQUENCE.map((_, cIndex) => {
              const level = getRiskLevel(lIndex, cIndex);
              const isSelected = lIndex === likelihood && cIndex === consequence;
              return (
                <div
                  key={cIndex}
                  onClick={() => handleCellClick(lIndex, cIndex)}
                  className={`h-12 w-full flex items-center justify-center rounded-md text-white text-sm font-semibold
                    ${riskLevelColors[level]} 
                    ${!readOnly ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}
                    ${isSelected ? 'ring-4 ring-sky-500 ring-offset-2 dark:ring-offset-slate-800' : ''}
                  `}
                >
                  {level.charAt(0)}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
      <div className="mt-4 flex justify-between items-center bg-slate-100 dark:bg-slate-700 p-3 rounded-lg">
          <h4 className="font-semibold">Calculated Risk Level:</h4>
          <span className={`px-3 py-1 text-sm font-bold text-white rounded-full ${riskLevelColors[currentRiskLevel]}`}>
            {currentRiskLevel}
          </span>
      </div>
    </div>
  );
};

export default RiskMatrix;
