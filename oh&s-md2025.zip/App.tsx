
import React from 'react';
import { HashRouter, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Dashboard from './pages/Dashboard';
import ReportIncident from './pages/ReportIncident';
import Checklists from './pages/Checklists';
import RiskAssessments from './pages/RiskAssessments';
import Documents from './pages/Documents';

function App() {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen font-sans text-slate-800 dark:text-slate-200">
        <Header />
        <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/report" element={<ReportIncident />} />
            <Route path="/checklists" element={<Checklists />} />
            <Route path="/risks" element={<RiskAssessments />} />
            <Route path="/documents" element={<Documents />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
}

export default App;
