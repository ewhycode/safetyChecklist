
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { IncidentReport, IncidentType, ReportStatus } from '../types';
import { CameraIcon, UploadIcon } from '../components/Icons';

const ReportIncident: React.FC = () => {
  const navigate = useNavigate();
  const [incidents, setIncidents] = useLocalStorage<IncidentReport[]>('incidents', []);
  
  const [type, setType] = useState<IncidentType>(IncidentType.Hazard);
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [photo, setPhoto] = useState<string | undefined>(undefined);
  const [photoName, setPhotoName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !location) {
        alert("Please fill out all fields.");
        return;
    }
    
    setIsSubmitting(true);
    const newIncident: IncidentReport = {
      id: `INC-${Date.now()}`,
      type,
      description,
      location,
      photo,
      date: new Date().toISOString(),
      status: ReportStatus.Reported,
    };
    
    // Simulate async submission
    setTimeout(() => {
        setIncidents([...incidents, newIncident]);
        setIsSubmitting(false);
        navigate('/');
    }, 500);
  };

  return (
    <Card title="Report a New Incident">
      <p className="mb-6 text-sm text-slate-600 dark:text-slate-400">Use this form to report any hazards, near misses, or injuries. Provide as much detail as possible.</p>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="type" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Type of Incident</label>
          <select
            id="type"
            value={type}
            onChange={(e) => setType(e.target.value as IncidentType)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 dark:border-slate-600 dark:bg-slate-700 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm rounded-md"
          >
            {Object.values(IncidentType).map(it => <option key={it} value={it}>{it}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="location" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Location</label>
          <input
            type="text"
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g., Warehouse Section B, Kitchen"
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 dark:bg-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
            required
          />
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
          <textarea
            id="description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what happened or what the hazard is..."
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 dark:bg-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Upload Photo (Optional)</label>
          <div className="mt-2 flex items-center justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <CameraIcon className="mx-auto h-12 w-12 text-slate-400"/>
              <div className="flex text-sm text-slate-600 dark:text-slate-400">
                <label htmlFor="file-upload" className="relative cursor-pointer bg-white dark:bg-slate-800 rounded-md font-medium text-sky-600 hover:text-sky-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-sky-500">
                  <span>Upload a file</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" capture="environment" onChange={handlePhotoUpload} />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-500">PNG, JPG, GIF up to 10MB</p>
            </div>
          </div>
          {photoName && 
            <div className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                <span className="font-semibold">Selected file:</span> {photoName}
            </div>
          }
           {photo && 
            <div className="mt-4">
                <img src={photo} alt="Incident preview" className="max-h-48 rounded-lg mx-auto" />
            </div>
          }
        </div>

        <div className="flex justify-end pt-2">
          <Button type="submit" variant="primary" size="lg" disabled={isSubmitting} leftIcon={<UploadIcon className="h-5 w-5"/>}>
            {isSubmitting ? 'Submitting...' : 'Submit Report'}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default ReportIncident;
