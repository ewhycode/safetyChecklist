
import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Modal from '../components/Modal';
import RiskMatrix from '../components/RiskMatrix';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { IncidentReport, RiskAssessment, ReportStatus, RiskLevel } from '../types';

const statusColors: Record<ReportStatus, string> = {
    [ReportStatus.Reported]: 'bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-200',
    [ReportStatus.Assessed]: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200',
    [ReportStatus.Resolved]: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
};

const RiskAssessmentsPage: React.FC = () => {
    const [incidents, setIncidents] = useLocalStorage<IncidentReport[]>('incidents', []);
    const [assessments, setAssessments] = useLocalStorage<RiskAssessment[]>('assessments', []);
    const [isModalOpen, setModalOpen] = useState(false);
    const [selectedIncident, setSelectedIncident] = useState<IncidentReport | null>(null);

    const openAssessmentModal = (incident: IncidentReport) => {
        setSelectedIncident(incident);
        setModalOpen(true);
    };

    const handleSaveAssessment = (assessment: RiskAssessment) => {
        setAssessments(prev => [...prev.filter(a => a.incidentId !== assessment.incidentId), assessment]);
        setIncidents(prev => prev.map(inc => 
            inc.id === assessment.incidentId ? { ...inc, status: ReportStatus.Assessed, riskAssessmentId: assessment.id } : inc
        ));
        setModalOpen(false);
        setSelectedIncident(null);
    };

    const handleResolveIncident = (incidentId: string) => {
        setIncidents(prev => prev.map(inc => 
            inc.id === incidentId ? { ...inc, status: ReportStatus.Resolved } : inc
        ));
    };

    const findAssessment = (incidentId: string) => assessments.find(a => a.incidentId === incidentId);

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Incident Risk Assessments</h1>
            <Card title="All Reported Incidents">
                {incidents.length > 0 ? (
                    <div className="divide-y divide-slate-200 dark:divide-slate-700">
                        {incidents.map(incident => {
                            const assessment = findAssessment(incident.id);
                            return (
                                <div key={incident.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                                    <div className="flex-grow">
                                        <p className="font-semibold">{incident.type}: <span className="font-normal">{incident.location}</span></p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">{incident.description}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Reported on: {new Date(incident.date).toLocaleString()}</p>
                                    </div>
                                    <div className="flex items-center gap-4 flex-shrink-0">
                                        <span className={`px-3 py-1 text-xs font-bold rounded-full ${statusColors[incident.status]}`}>{incident.status}</span>
                                        {incident.status !== ReportStatus.Resolved && (
                                            <>
                                                <Button size="sm" variant="secondary" onClick={() => openAssessmentModal(incident)}>
                                                    {assessment ? 'View/Edit' : 'Assess'}
                                                </Button>
                                                {incident.status === ReportStatus.Assessed && (
                                                    <Button size="sm" variant="primary" onClick={() => handleResolveIncident(incident.id)}>Resolve</Button>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <p className="text-slate-500 dark:text-slate-400 text-center py-8">No incidents to assess.</p>
                )}
            </Card>

            {selectedIncident && (
                <AssessmentModal
                    isOpen={isModalOpen}
                    onClose={() => setModalOpen(false)}
                    incident={selectedIncident}
                    existingAssessment={findAssessment(selectedIncident.id)}
                    onSave={handleSaveAssessment}
                />
            )}
        </div>
    );
};

interface AssessmentModalProps {
    isOpen: boolean;
    onClose: () => void;
    incident: IncidentReport;
    existingAssessment?: RiskAssessment;
    onSave: (assessment: RiskAssessment) => void;
}

const AssessmentModal: React.FC<AssessmentModalProps> = ({ isOpen, onClose, incident, existingAssessment, onSave }) => {
    const [likelihood, setLikelihood] = useState(existingAssessment?.likelihood || 0);
    const [consequence, setConsequence] = useState(existingAssessment?.consequence || 0);
    const [mitigationSteps, setMitigationSteps] = useState(existingAssessment?.mitigationSteps || '');

    const getRiskLevel = (l: number, c: number): RiskLevel => {
        const score = (l + 1) * (c + 1);
        if (score <= 4) return RiskLevel.Low;
        if (score <= 9) return RiskLevel.Medium;
        if (score <= 15) return RiskLevel.High;
        return RiskLevel.Extreme;
    };

    const handleSave = () => {
        const newAssessment: RiskAssessment = {
            id: existingAssessment?.id || `RA-${Date.now()}`,
            incidentId: incident.id,
            likelihood,
            consequence,
            riskLevel: getRiskLevel(likelihood, consequence),
            mitigationSteps,
            assessmentDate: new Date().toISOString(),
        };
        onSave(newAssessment);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Assess Incident: ${incident.id}`}>
            <div className="space-y-6">
                <div>
                    <h4 className="font-semibold text-slate-800 dark:text-slate-100">Incident Details</h4>
                    <p className="text-sm mt-1 p-3 bg-slate-100 dark:bg-slate-700 rounded-md">{incident.description}</p>
                    {incident.photo && <img src={incident.photo} alt="Incident" className="mt-2 rounded-lg max-h-48" />}
                </div>
                <div>
                    <h4 className="font-semibold text-slate-800 dark:text-slate-100 mb-2">Risk Matrix</h4>
                    <RiskMatrix 
                        likelihood={likelihood}
                        consequence={consequence}
                        onRiskChange={(l, c) => { setLikelihood(l); setConsequence(c); }}
                    />
                </div>
                <div>
                     <label htmlFor="mitigation" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Mitigation Steps</label>
                      <textarea
                        id="mitigation"
                        rows={4}
                        value={mitigationSteps}
                        onChange={(e) => setMitigationSteps(e.target.value)}
                        placeholder="Document the actions taken or planned to mitigate this risk..."
                        className="mt-1 block w-full border border-slate-300 dark:border-slate-600 dark:bg-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                        required
                    />
                </div>
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button variant="primary" onClick={handleSave}>Save Assessment</Button>
                </div>
            </div>
        </Modal>
    );
};

export default RiskAssessmentsPage;
