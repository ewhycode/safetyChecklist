
import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Modal from '../components/Modal';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Checklist } from '../types';
import { generateChecklistFromAI } from '../services/geminiService';
import { PlusIcon, SparklesIcon } from '../components/Icons';

// Initial sample checklists
const initialChecklists: Checklist[] = [
    {
        id: 'CHK-1',
        title: 'Daily Forklift Pre-start Check',
        createdBy: 'template',
        items: [
            { text: 'Check fluid levels (oil, hydraulic, coolant)', completed: false },
            { text: 'Inspect tires for wear and pressure', completed: false },
            { text: 'Test horn, lights, and alarms', completed: false },
            { text: 'Check forks and mast for damage', completed: false },
        ]
    },
    {
        id: 'CHK-2',
        title: 'Weekly First-Aid Kit Audit',
        createdBy: 'template',
        items: [
            { text: 'Check stock of bandages and dressings', completed: false },
            { text: 'Ensure antiseptic wipes are in date', completed: false },
            { text: 'Verify emergency contact list is current', completed: false },
        ]
    }
];

const ChecklistPage: React.FC = () => {
    const [checklists, setChecklists] = useLocalStorage<Checklist[]>('checklists', initialChecklists);
    const [isCreateModalOpen, setCreateModalOpen] = useState(false);
    const [isAiModalOpen, setAiModalOpen] = useState(false);
    const [isViewModalOpen, setViewModalOpen] = useState(false);
    const [activeChecklist, setActiveChecklist] = useState<Checklist | null>(null);

    const openChecklist = (checklist: Checklist) => {
        setActiveChecklist(JSON.parse(JSON.stringify(checklist))); // Deep copy to avoid direct state mutation
        setViewModalOpen(true);
    };

    const handleChecklistItem = (itemIndex: number, checked: boolean) => {
        if (activeChecklist) {
            const updatedItems = [...activeChecklist.items];
            updatedItems[itemIndex].completed = checked;
            setActiveChecklist({ ...activeChecklist, items: updatedItems });
        }
    };
    
    const saveChecklistCompletion = () => {
        if (activeChecklist) {
            const updatedChecklist = {
                ...activeChecklist,
                dateCompleted: new Date().toISOString(),
                completedBy: "User", // In a real app, this would be the logged-in user
            };
            setChecklists(checklists.map(c => c.id === updatedChecklist.id ? updatedChecklist : c));
            // Create a new instance of the template for future use
            if (activeChecklist.createdBy === 'template') {
                 const newInstance = {
                     ...initialChecklists.find(c => c.id === activeChecklist.id)!,
                     id: `CHK-${Date.now()}`
                 };
                 setChecklists(prev => [...prev, newInstance]);
            }
            setViewModalOpen(false);
            setActiveChecklist(null);
        }
    };
    
    const pendingChecklists = checklists.filter(c => !c.dateCompleted);
    const completedChecklists = checklists.filter(c => c.dateCompleted);

    return (
        <div className="space-y-6">
            <div className="md:flex justify-between items-center">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Safety Checklists</h1>
                <div className="mt-4 md:mt-0 flex gap-2">
                    <Button onClick={() => setAiModalOpen(true)} variant="primary" leftIcon={<SparklesIcon className="h-5 w-5"/>}>Create with AI</Button>
                </div>
            </div>
            
            <Card title="Pending Checklists">
                {pendingChecklists.length > 0 ? (
                    <div className="space-y-3">
                        {pendingChecklists.map(c => (
                            <div key={c.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-md">
                                <p className="font-semibold">{c.title}</p>
                                <Button size="sm" onClick={() => openChecklist(c)}>Start</Button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-slate-500 dark:text-slate-400 text-center py-4">All checklists are complete!</p>
                )}
            </Card>

            <Card title="Completed Checklists">
                 {completedChecklists.length > 0 ? (
                    <div className="space-y-3">
                        {completedChecklists.map(c => (
                            <div key={c.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-md opacity-70">
                                <div>
                                    <p className="font-semibold text-slate-600 dark:text-slate-300">{c.title}</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Completed on {new Date(c.dateCompleted!).toLocaleDateString()}</p>
                                </div>
                                <span className="text-emerald-600 dark:text-emerald-400 font-bold">Done</span>
                            </div>
                        ))}
                    </div>
                ) : (
                     <p className="text-slate-500 dark:text-slate-400 text-center py-4">No checklists have been completed yet.</p>
                )}
            </Card>

            {/* AI Generation Modal */}
            <AIChecklistModal 
                isOpen={isAiModalOpen} 
                onClose={() => setAiModalOpen(false)}
                onChecklistCreated={(newChecklist) => {
                    setChecklists(prev => [...prev, newChecklist]);
                    setAiModalOpen(false);
                }}
            />

            {/* View/Complete Checklist Modal */}
            <Modal isOpen={isViewModalOpen} onClose={() => setViewModalOpen(false)} title={activeChecklist?.title || ''}>
                <div className="space-y-4">
                    {activeChecklist?.items.map((item, index) => (
                         <label key={index} className="flex items-center p-3 bg-slate-100 dark:bg-slate-700 rounded-lg cursor-pointer">
                             <input 
                                 type="checkbox" 
                                 checked={item.completed}
                                 onChange={(e) => handleChecklistItem(index, e.target.checked)}
                                 className="h-5 w-5 rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                             />
                             <span className="ml-3 text-slate-800 dark:text-slate-200">{item.text}</span>
                         </label>
                    ))}
                </div>
                 <div className="mt-6 flex justify-end">
                    <Button onClick={saveChecklistCompletion} variant="primary">Mark as Complete</Button>
                </div>
            </Modal>
        </div>
    );
};


const AIChecklistModal: React.FC<{isOpen: boolean, onClose: () => void, onChecklistCreated: (checklist: Checklist) => void}> = ({ isOpen, onClose, onChecklistCreated }) => {
    const [topic, setTopic] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleGenerate = async () => {
        if (!topic) {
            setError('Please enter a topic.');
            return;
        }
        setIsLoading(true);
        setError('');
        try {
            const items = await generateChecklistFromAI(topic);
            const newChecklist: Checklist = {
                id: `CHK-${Date.now()}`,
                title: topic,
                createdBy: 'ai',
                items: items.map(text => ({ text, completed: false })),
            };
            onChecklistCreated(newChecklist);
            setTopic('');
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="Create Checklist with AI"
        >
            <div className="space-y-4">
                <p className="text-sm text-slate-600 dark:text-slate-400">Describe the equipment or task you need a safety checklist for. (e.g., "Ladder Safety", "Kitchen Closing Duties")</p>
                <div>
                    <label htmlFor="ai-topic" className="sr-only">Checklist Topic</label>
                    <input 
                        id="ai-topic"
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="e.g., Daily Forklift Pre-start Check"
                        className="w-full border border-slate-300 dark:border-slate-600 dark:bg-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    />
                </div>
                {error && <p className="text-rose-600 text-sm">{error}</p>}
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleGenerate} disabled={isLoading} leftIcon={isLoading ? null : <SparklesIcon className="h-5 w-5"/>}>
                        {isLoading ? 'Generating...' : 'Generate'}
                    </Button>
                </div>
            </div>
        </Modal>
    );
}


export default ChecklistPage;
