
import React, { useRef, useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { SafetyDocument } from '../types';
import { DocumentTextIcon, UploadIcon, TrashIcon } from '../components/Icons';

// Initial sample documents
const initialDocuments: SafetyDocument[] = [
    { id: 'DOC-2', name: 'Public Liability Insurance Certificate.pdf', fileType: 'application/pdf', uploadDate: new Date('2023-09-01').toISOString() },
    { id: 'DOC-3', name: 'Emergency Evacuation Plan.docx', fileType: 'application/msword', uploadDate: new Date('2023-05-20').toISOString() },
    { id: 'DOC-4', name: 'First Aid Officer Certificates.zip', fileType: 'application/zip', uploadDate: new Date('2023-11-01').toISOString() },
];

const DocumentsPage: React.FC = () => {
    const [documents, setDocuments] = useLocalStorage<SafetyDocument[]>('documents', initialDocuments);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const newDocument: SafetyDocument = {
                id: `DOC-${Date.now()}`,
                name: file.name,
                fileType: file.type,
                uploadDate: new Date().toISOString(),
                // fileData would be uploaded to a server in a real app
            };
            setDocuments(prev => [newDocument, ...prev]);
        }
        // Reset file input
        if(e.target) {
            e.target.value = '';
        }
    };
    
    const handleDelete = (docId: string) => {
        if (window.confirm("Are you sure you want to delete this document?")) {
            setDocuments(docs => docs.filter(d => d.id !== docId));
        }
    };

    return (
        <div className="space-y-6">
            <div className="md:flex justify-between items-center">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Safety Documents Hub</h1>
                 <div className="mt-4 md:mt-0">
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden"
                    />
                    <Button onClick={handleFileUploadClick} leftIcon={<UploadIcon className="h-5 w-5" />}>
                        Upload Document
                    </Button>
                </div>
            </div>

            <Card>
                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                    {documents.length > 0 ? (
                        documents.map(doc => (
                            <div key={doc.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                                <div className="flex items-center gap-4 flex-grow">
                                    <DocumentTextIcon className="h-8 w-8 text-sky-500 flex-shrink-0"/>
                                    <div>
                                        <p className="font-semibold text-slate-800 dark:text-slate-100">{doc.name}</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">Uploaded: {new Date(doc.uploadDate).toLocaleDateString()}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center">
                                    <Button variant="ghost" size="sm">View</Button>
                                    <Button variant="ghost" size="sm" className="text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-900/50" onClick={() => handleDelete(doc.id)}>
                                        <TrashIcon className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-center py-12">
                            <DocumentTextIcon className="mx-auto h-12 w-12 text-slate-400"/>
                            <h3 className="mt-2 text-sm font-medium text-slate-900 dark:text-slate-100">No documents uploaded</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Get started by uploading your first safety document.</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default DocumentsPage;
