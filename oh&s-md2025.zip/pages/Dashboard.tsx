import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { IncidentReport, ReportStatus, Checklist } from '../types';
import { PlusIcon, ClipboardCheckIcon, ExclamationTriangleIcon, DocumentTextIcon, ShieldCheckIcon } from '../components/Icons';

const DashboardStat: React.FC<{ icon: React.ReactNode; label: string; value: string | number; color: string }> = ({ icon, label, value, color }) => (
    <div className="flex items-center p-4 bg-slate-100 dark:bg-slate-800/50 rounded-lg">
        <div className={`flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full ${color} text-white`}>
            {icon}
        </div>
        <div className="ml-4">
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">{value}</p>
        </div>
    </div>
);

const Dashboard: React.FC = () => {
    const [incidents] = useLocalStorage<IncidentReport[]>('incidents', []);
    const [checklists] = useLocalStorage<Checklist[]>('checklists', []);

    const openIncidents = incidents.filter(i => i.status !== ReportStatus.Resolved).length;
    const pendingChecklists = checklists.filter(c => !c.dateCompleted).length;

    return (
        <div className="space-y-6">
            <div className="md:flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Welcome to SiteSafe</h1>
                    <p className="mt-1 text-slate-600 dark:text-slate-400">Your OH&S dashboard at a glance.</p>
                </div>
                <div className="mt-4 md:mt-0 flex gap-2">
                     <Link to="/report">
                        <Button variant="primary" leftIcon={<PlusIcon className="h-5 w-5"/>}>New Report</Button>
                    </Link>
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <DashboardStat icon={<ExclamationTriangleIcon className="h-6 w-6" />} label="Open Incidents" value={openIncidents} color="bg-rose-500" />
                <DashboardStat icon={<ClipboardCheckIcon className="h-6 w-6" />} label="Pending Checklists" value={pendingChecklists} color="bg-amber-500" />
                <DashboardStat icon={<DocumentTextIcon className="h-6 w-6" />} label="Safety Documents" value={4} color="bg-sky-500" />
            </div>

            <Card title="Quick Actions">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-center">
                    <Link to="/report" className="block p-4 bg-sky-100 hover:bg-sky-200 dark:bg-sky-900/50 dark:hover:bg-sky-900 rounded-lg transition-colors">
                        <ExclamationTriangleIcon className="h-8 w-8 mx-auto text-sky-600 dark:text-sky-400" />
                        <p className="mt-2 font-semibold">Report Incident</p>
                    </Link>
                    <Link to="/checklists" className="block p-4 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-900/50 dark:hover:bg-emerald-900 rounded-lg transition-colors">
                        <ClipboardCheckIcon className="h-8 w-8 mx-auto text-emerald-600 dark:text-emerald-400" />
                        <p className="mt-2 font-semibold">Start Checklist</p>
                    </Link>
                    <Link to="/risks" className="block p-4 bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/50 dark:hover:bg-amber-900 rounded-lg transition-colors">
                        <ShieldCheckIcon className="h-8 w-8 mx-auto text-amber-600 dark:text-amber-400" />
                        <p className="mt-2 font-semibold">Assess Risk</p>
                    </Link>
                    <Link to="/documents" className="block p-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg transition-colors">
                        <DocumentTextIcon className="h-8 w-8 mx-auto text-slate-600 dark:text-slate-400" />
                        <p className="mt-2 font-semibold">View Documents</p>
                    </Link>
                </div>
            </Card>

            <Card title="Recent Incidents">
                <div className="space-y-4">
                    {incidents.length > 0 ? (
                        incidents.slice(0, 3).map(incident => (
                            <div key={incident.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-md">
                                <div>
                                    <p className="font-semibold">{incident.type}: <span className="font-normal">{incident.description.substring(0, 50)}...</span></p>
                                    <p className="text-sm text-slate-500 dark:text-slate-400">{new Date(incident.date).toLocaleDateString()}</p>
                                </div>
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                    incident.status === ReportStatus.Resolved ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200' :
                                    incident.status === ReportStatus.Assessed ? 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200' :
                                    'bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-200'
                                }`}>
                                    {incident.status}
                                </span>
                            </div>
                        ))
                    ) : (
                        <p className="text-slate-500 dark:text-slate-400 text-center py-4">No incidents reported yet.</p>
                    )}
                </div>
                 {incidents.length > 3 && (
                    <div className="mt-4 text-center">
                        <Link to="/risks">
                            <Button variant="ghost">View All Incidents</Button>
                        </Link>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default Dashboard;