
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This is a fallback for development. The user should not see this.
  console.warn("API_KEY is not set. Using a placeholder.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || " " });

export const generateChecklistFromAI = async (topic: string): Promise<string[]> => {
  if (!API_KEY) {
    // Return mock data if API key is not available
    return Promise.resolve([
        `Check that the ${topic} is clean and free of debris.`,
        `Inspect all safety guards are in place for the ${topic}.`,
        `Ensure emergency stop button for the ${topic} is accessible and functional.`,
        `Verify fluid levels (oil, hydraulic, coolant) for the ${topic}.`,
        `Check for any visible leaks on the ${topic}.`
    ]);
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a concise safety checklist for a "${topic}". The checklist should be practical for a daily or weekly workplace inspection. Focus on key safety items.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            checklist_items: {
              type: Type.ARRAY,
              description: "A list of safety checklist items.",
              items: {
                type: Type.STRING,
                description: "A single, actionable checklist item."
              }
            }
          }
        },
      },
    });

    const jsonString = response.text;
    const parsed = JSON.parse(jsonString);

    if (parsed && Array.isArray(parsed.checklist_items)) {
      return parsed.checklist_items;
    } else {
      console.error("AI response was not in the expected format:", parsed);
      return [];
    }
  } catch (error) {
    console.error("Error generating checklist from AI:", error);
    throw new Error("Failed to generate checklist. Please try again.");
  }
};
