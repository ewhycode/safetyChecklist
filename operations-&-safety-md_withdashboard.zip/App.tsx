import React from 'react';
import { HashRouter, Route, Routes, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Dashboard from './pages/Dashboard';
import ReportIncident from './pages/ReportIncident';
import Checklists from './pages/Checklists';
import RiskAssessments from './pages/RiskAssessments';
import Documents from './pages/Documents';
import Login from './pages/Login';
import Map from './pages/Map';
import LostProperty from './pages/LostProperty';
import ProtectedRoute from './components/ProtectedRoute';
import { useAuth } from './context/AuthContext';
import { Role } from './types';
import './App.css';

const getHomeRoute = (role: Role) => {
  switch (role) {
    case 'supervisor':
      return '/';
    case 'vendor':
      return '/checklists';
    case 'user':
      return '/report';
    default:
      return '/';
  }
};

function App() {
  const { user } = useAuth();

  if (!user) {
    return (
      <HashRouter>
        <Routes>
          <Route path="*" element={<Login />} />
        </Routes>
      </HashRouter>
    );
  }

  return (
    <HashRouter>
      <div className="app-container">
        <Header />
        <main className="main-content container">
          <Routes>
            {/* Supervisor Routes */}
            <Route path="/" element={<ProtectedRoute allowedRoles={['supervisor']}><Dashboard /></ProtectedRoute>} />
            <Route path="/risks" element={<ProtectedRoute allowedRoles={['supervisor']}><RiskAssessments /></ProtectedRoute>} />
            <Route path="/documents" element={<ProtectedRoute allowedRoles={['supervisor']}><Documents /></ProtectedRoute>} />
            
            {/* Vendor Routes */}
            <Route path="/checklists" element={<ProtectedRoute allowedRoles={['vendor']}><Checklists /></ProtectedRoute>} />

            {/* User Routes - now also accessible by Vendor */}
            <Route path="/report" element={<ProtectedRoute allowedRoles={['user', 'supervisor', 'vendor']}><ReportIncident /></ProtectedRoute>} />
            <Route path="/lost-property" element={<ProtectedRoute allowedRoles={['user', 'vendor']}><LostProperty /></ProtectedRoute>} />

            {/* Common Routes */}
            <Route path="/map" element={<ProtectedRoute allowedRoles={['supervisor', 'vendor', 'user']}><Map /></ProtectedRoute>} />
            
            {/* Redirect from login and handle unknown paths */}
            <Route path="/login" element={<Navigate to={getHomeRoute(user.role)} />} />
            <Route path="*" element={
              <div style={{ textAlign: 'center', marginTop: '4rem' }}>
                <h2>404 - Page Not Found</h2>
                <p>The page you are looking for does not exist or you do not have permission to view it.</p>
              </div>
            } /> 
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
}

export default App;