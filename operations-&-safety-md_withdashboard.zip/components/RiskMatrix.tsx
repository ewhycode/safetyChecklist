import React from 'react';
import { RiskLevel } from '../types';
import './RiskMatrix.css';

const LIKELIHOOD = ['Rare', 'Unlikely', 'Possible', 'Likely', 'Almost Certain'];
const CONSEQUENCE = ['Insignificant', 'Minor', 'Moderate', 'Major', 'Catastrophic'];

const getRiskLevel = (likelihood: number, consequence: number): RiskLevel => {
  const score = (likelihood + 1) * (consequence + 1);
  if (score <= 4) return RiskLevel.Low;
  if (score <= 9) return RiskLevel.Medium;
  if (score <= 15) return RiskLevel.High;
  return RiskLevel.Extreme;
};

const riskLevelClasses: Record<RiskLevel, string> = {
  [RiskLevel.Low]: 'risk-low',
  [RiskLevel.Medium]: 'risk-medium',
  [RiskLevel.High]: 'risk-high',
  [RiskLevel.Extreme]: 'risk-extreme',
  [RiskLevel.Unknown]: 'risk-unknown',
};

interface RiskMatrixProps {
  likelihood: number; // 0-4
  consequence: number; // 0-4
  onRiskChange: (likelihood: number, consequence: number) => void;
  readOnly?: boolean;
}

const RiskMatrix: React.FC<RiskMatrixProps> = ({ likelihood, consequence, onRiskChange, readOnly = false }) => {

  const handleCellClick = (lIndex: number, cIndex: number) => {
    if (!readOnly) {
      onRiskChange(lIndex, cIndex);
    }
  };
  
  const currentRiskLevel = getRiskLevel(likelihood, consequence);

  return (
    <div className="risk-matrix-wrapper">
      <div className="risk-matrix-grid">
        <div className="header-cell likelihood-header">Likelihood</div>
        {CONSEQUENCE.map((c) => (
          <div key={c} className="header-cell consequence-header">{c}</div>
        ))}

        {LIKELIHOOD.map((l, lIndex) => (
          <React.Fragment key={lIndex}>
            <div className="header-cell likelihood-label">{l}</div>
            {CONSEQUENCE.map((_, cIndex) => {
              const level = getRiskLevel(lIndex, cIndex);
              const isSelected = lIndex === likelihood && cIndex === consequence;
              const cellClasses = [
                'risk-cell',
                riskLevelClasses[level],
                !readOnly ? 'clickable' : '',
                isSelected ? 'selected' : ''
              ].join(' ').trim();
              
              return (
                <div
                  key={cIndex}
                  onClick={() => handleCellClick(lIndex, cIndex)}
                  className={cellClasses}
                >
                  {level.charAt(0)}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
      <div className="risk-summary">
          <h4 className="summary-label">Calculated Risk Level:</h4>
          <span className={`summary-badge ${riskLevelClasses[currentRiskLevel]}`}>
            {currentRiskLevel}
          </span>
      </div>
    </div>
  );
};

export default RiskMatrix;