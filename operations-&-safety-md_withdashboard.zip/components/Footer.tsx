import React from 'react';
import './Footer.css';

const Footer: React.FC = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-container">
        <p className="footer-text">
          © {new Date().getFullYear()} Operations & Safety MD. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;