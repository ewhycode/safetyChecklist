import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Role } from '../types';

interface ProtectedRouteProps {
  children: JSX.Element;
  allowedRoles: Role[];
}

const getHomeRoute = (role: Role) => {
  switch (role) {
    case 'supervisor': return '/';
    case 'vendor': return '/checklists';
    case 'user': return '/report';
    default: return '/';
  }
};

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { user } = useAuth();

  if (!user) {
    // This should theoretically not be hit if App.tsx logic is correct,
    // but serves as a fallback.
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    // If user is not authorized, redirect them to their own home page.
    return <Navigate to={getHomeRoute(user.role)} replace />;
  }

  return children;
};

export default ProtectedRoute;
