import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { ShieldCheckIcon, MenuIcon, XIcon, SunIcon, MoonIcon } from './Icons';
import Button from './Button';
import './Header.css';

const NavItem: React.FC<{ to: string; children: React.ReactNode; onClick: () => void }> = ({ to, children, onClick }) => (
  <NavLink
    to={to}
    onClick={onClick}
    className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
  >
    {children}
  </NavLink>
);

const ThemeToggleButton: React.FC = () => {
    const { theme, toggleTheme } = useTheme();
    return (
        <button onClick={toggleTheme} className="theme-toggle-button" aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}>
            {theme === 'light' ? (
                <MoonIcon className="theme-icon" />
            ) : (
                <SunIcon className="theme-icon" />
            )}
        </button>
    );
};

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  const closeMenu = () => setIsMenuOpen(false);
  
  const handleLogout = () => {
    closeMenu();
    logout();
  }

  const renderNavLinks = () => {
    if (!user) return null;

    switch(user.role) {
      case 'supervisor':
        return (
          <>
            <NavItem to="/" onClick={closeMenu}>Dashboard</NavItem>
            <NavItem to="/report" onClick={closeMenu}>Report Incident</NavItem>
            <NavItem to="/risks" onClick={closeMenu}>Assessments</NavItem>
            <NavItem to="/documents" onClick={closeMenu}>Documents</NavItem>
            <NavItem to="/map" onClick={closeMenu}>Map</NavItem>
          </>
        );
      case 'vendor':
        return (
          <>
            <NavItem to="/checklists" onClick={closeMenu}>Checklists</NavItem>
            <NavItem to="/report" onClick={closeMenu}>Report Incident</NavItem>
            <NavItem to="/lost-property" onClick={closeMenu}>Lost Property</NavItem>
            <NavItem to="/map" onClick={closeMenu}>Map</NavItem>
          </>
        );
      case 'user':
        return (
          <>
            <NavItem to="/report" onClick={closeMenu}>Report Incident</NavItem>
            <NavItem to="/lost-property" onClick={closeMenu}>Lost Property</NavItem>
            <NavItem to="/map" onClick={closeMenu}>Map</NavItem>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <header className="site-header">
      <div className="container header-container">
        <div className="header-branding">
          <NavLink to="/" className="branding-link" onClick={closeMenu}>
              <ShieldCheckIcon className="branding-icon" />
              <span className="branding-text">Operations & Safety MD</span>
          </NavLink>
        </div>
        
        <div className="nav-wrapper">
          <nav className="header-nav">
            {renderNavLinks()}
          </nav>

          <div className="header-actions">
            <ThemeToggleButton />
            <span className="user-name">Hi, {user?.name}</span>
            <Button onClick={handleLogout} variant="secondary" size="sm">Logout</Button>
          </div>
        </div>

        <div className="mobile-menu-toggle">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="menu-toggle-button"
            aria-label="Open main menu"
          >
            {isMenuOpen ? <XIcon className="menu-icon" /> : <MenuIcon className="menu-icon" />}
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="mobile-menu" id="mobile-menu">
          <nav className="mobile-nav">
            {renderNavLinks()}
          </nav>
           <div className="mobile-actions">
             <ThemeToggleButton />
             <Button onClick={handleLogout} variant="secondary" size="sm">Logout</Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;