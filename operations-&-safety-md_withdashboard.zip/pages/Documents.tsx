import React, { useRef } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { useAppContext } from '../context/AppContext';
import { DocumentTextIcon, UploadIcon, TrashIcon } from '../components/Icons';
import './Documents.css';

const DocumentsPage: React.FC = () => {
    const { documents, addDocument, deleteDocument } = useAppContext();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            addDocument(file);
        }
        // Reset file input
        if(e.target) {
            e.target.value = '';
        }
    };
    
    const handleDelete = (docId: string) => {
        if (window.confirm("Are you sure you want to delete this document?")) {
            deleteDocument(docId);
        }
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">Safety Documents Hub</h1>
                 <div className="header-actions">
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden-file-input"
                    />
                    <Button onClick={handleFileUploadClick} leftIcon={<UploadIcon className="icon-sm" />}>
                        Upload Document
                    </Button>
                </div>
            </div>

            <Card>
                <div className="document-list">
                    {documents.length > 0 ? (
                        documents.map(doc => (
                            <div key={doc.id} className="document-item">
                                <div className="document-info">
                                    <DocumentTextIcon className="document-icon"/>
                                    <div>
                                        <p className="document-name">{doc.name}</p>
                                        <p className="document-date">Uploaded: {new Date(doc.uploadDate).toLocaleDateString()}</p>
                                    </div>
                                </div>
                                <div className="document-actions">
                                    <Button variant="ghost" size="sm">View</Button>
                                    <Button variant="ghost" size="sm" className="button-delete" onClick={() => handleDelete(doc.id)}>
                                        <TrashIcon className="icon-xs" />
                                    </Button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="empty-state-container">
                            <DocumentTextIcon className="empty-state-icon"/>
                            <h3 className="empty-state-title">No documents uploaded</h3>
                            <p className="empty-state-text">Get started by uploading your first safety document.</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default DocumentsPage;