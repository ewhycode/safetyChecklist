import React, { useEffect, useRef, useState } from 'react';
import Card from '../components/Card';
import './Map.css';

// Fix: Add a global declaration for window.google to satisfy TypeScript, as Google Maps is loaded via a script tag.
declare global {
    interface Window {
        google: any;
    }
}

const marvelStadiumCoords = { lat: -37.818272, lng: 144.952042 };

const markers = [
    { position: { lat: -37.8180, lng: 144.9530 }, title: "Vendor Area A" },
    { position: { lat: -37.8189, lng: 144.9525 }, title: "Vendor Area B" },
    { position: { lat: -37.8175, lng: 144.9515 }, title: "Main Stage" },
    { position: { lat: -37.8185, lng: 144.9505 }, title: "Entry Gate 1" },
    { position: { lat: -37.8192, lng: 144.9510 }, title: "Entry Gate 5" },
    { position: { lat: -37.8178, lng: 144.9540 }, title: "Emergency Exit Alpha" },
    { position: { lat: -37.8195, lng: 144.9518 }, title: "Emergency Exit Bravo" },
    { position: { lat: -37.8190, lng: 144.9500 }, title: "Lost Property Desk" },
];

const MapPage: React.FC = () => {
    const mapRef = useRef<HTMLDivElement>(null);
    const [mapError, setMapError] = useState(false);

    useEffect(() => {
        if (!window.google || !window.google.maps) {
            setMapError(true);
            return;
        }

        if (mapRef.current) {
            const mapOptions = {
                center: marvelStadiumCoords,
                zoom: 18,
                tilt: 45,
                heading: 90,
                mapId: 'SITESAFE_MAP_ID',
                disableDefaultUI: true,
                zoomControl: true,
            };

            const map = new window.google.maps.Map(mapRef.current, mapOptions);

            markers.forEach(markerInfo => {
                new window.google.maps.Marker({
                    position: markerInfo.position,
                    map: map,
                    title: markerInfo.title,
                });
            });
        }
    }, []);

    return (
        <div className="page-container">
            <h1 className="page-title">Event Map: Marvel Stadium</h1>
            <Card className="map-card">
                <div ref={mapRef} className="map-element">
                    {mapError && (
                        <div className="map-error-container">
                            <h3 className="map-error-title">Could not load map</h3>
                            <p className="map-error-text">
                                Please ensure you have a valid Google Maps API key in <code>index.html</code>.
                            </p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default MapPage;