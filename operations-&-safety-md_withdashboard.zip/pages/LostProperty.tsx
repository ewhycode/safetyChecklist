import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';
import { useAppContext } from '../context/AppContext';
import { LostPropertyReport } from '../types';
import { UploadIcon } from '../components/Icons';
import './LostProperty.css';

const LostProperty: React.FC = () => {
  const navigate = useNavigate();
  const { addLostProperty } = useAppContext();
  
  const [itemName, setItemName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [contactDetails, setContactDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName || !description || !location || !contactDetails) {
        alert("Please fill out all fields.");
        return;
    }
    
    setIsSubmitting(true);
    
    const newReportData: Omit<LostPropertyReport, 'id' | 'date'> = {
      itemName,
      description,
      location,
      contactDetails,
    };
    
    // Simulate async submission
    setTimeout(() => {
        addLostProperty(newReportData);
        setIsSubmitting(false);
        // Maybe navigate to a list of lost items or a success page
        alert('Lost property report submitted successfully!'); 
        navigate('/map');
    }, 500);
  };

  return (
    <Card title="Report Lost or Found Property">
      <p className="form-description">Use this form to report any items you have lost or found. Please provide clear details.</p>
      <form onSubmit={handleSubmit} className="lost-property-form">
        <div className="form-group">
          <label htmlFor="item-name">Item Name</label>
           <input
            type="text"
            id="item-name"
            value={itemName}
            onChange={(e) => setItemName(e.target.value)}
            placeholder="e.g., Black Wallet, iPhone 13"
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="location">Location Lost or Found</label>
          <input
            type="text"
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g., Near Gate 5, Food Court"
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the item, its contents, or where you found it..."
            className="form-textarea"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="contact">Contact Details</label>
          <input
            type="text"
            id="contact"
            value={contactDetails}
            onChange={(e) => setContactDetails(e.target.value)}
            placeholder="Your name and phone number or email"
            className="form-input"
            required
          />
        </div>

        <div className="form-actions">
          <Button type="submit" variant="primary" size="lg" disabled={isSubmitting} leftIcon={<UploadIcon className="h-5 w-5"/>}>
            {isSubmitting ? 'Submitting...' : 'Submit Report'}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default LostProperty;