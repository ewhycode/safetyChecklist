import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';
import { useAppContext } from '../context/AppContext';
import { IncidentReport } from '../types';
import { CameraIcon, UploadIcon } from '../components/Icons';
import './ReportIncident.css';

const ReportIncident: React.FC = () => {
  const navigate = useNavigate();
  const { addIncident } = useAppContext();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [photo, setPhoto] = useState<string | undefined>(undefined);
  const [photoName, setPhotoName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !location) {
        alert("Please fill out all fields.");
        return;
    }
    
    setIsSubmitting(true);
    
    const newIncidentData: Omit<IncidentReport, 'id' | 'date' | 'status'> = {
      title,
      description,
      location,
      photo,
    };
    
    // Simulate async submission
    setTimeout(() => {
        addIncident(newIncidentData);
        setIsSubmitting(false);
        navigate('/'); // Or to a confirmation page
    }, 500);
  };

  return (
    <Card title="Report a New Incident">
      <p className="form-description">Use this form to report any hazards, near misses, or injuries. Provide as much detail as possible.</p>
      <form onSubmit={handleSubmit} className="incident-form">
        <div className="form-group">
          <label htmlFor="title">Title / Type of Incident</label>
           <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Hazard, Near Miss, Injury"
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="location">Location</label>
          <input
            type="text"
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g., Warehouse Section B, Kitchen"
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what happened or what the hazard is..."
            className="form-textarea"
            required
          />
        </div>

        <div className="form-group">
          <label>Upload Photo (Optional)</label>
          <div className="file-drop-zone">
            <div className="drop-zone-content">
              <CameraIcon className="drop-zone-icon"/>
              <div className="drop-zone-text">
                <label htmlFor="file-upload" className="file-upload-label">
                  <span>Upload a file</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" capture="environment" onChange={handlePhotoUpload} />
                </label>
                <p>or drag and drop</p>
              </div>
              <p className="drop-zone-hint">PNG, JPG, GIF up to 10MB</p>
            </div>
          </div>
          {photoName && 
            <div className="file-name-preview">
                <strong>Selected file:</strong> {photoName}
            </div>
          }
           {photo && 
            <div className="image-preview-wrapper">
                <img src={photo} alt="Incident preview" className="image-preview" />
            </div>
          }
        </div>

        <div className="form-actions">
          <Button type="submit" variant="primary" size="lg" disabled={isSubmitting} leftIcon={<UploadIcon className="h-5 w-5"/>}>
            {isSubmitting ? 'Submitting...' : 'Submit Report'}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default ReportIncident;