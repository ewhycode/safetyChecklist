import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Modal from '../components/Modal';
import { Checklist } from '../types';
import { useAppContext } from '../context/AppContext';
import { PlusIcon, SparklesIcon } from '../components/Icons';
import './Checklists.css';

const ChecklistPage: React.FC = () => {
    const { checklists, setChecklists } = useAppContext();
    const [isViewModalOpen, setViewModalOpen] = useState(false);
    const [activeChecklist, setActiveChecklist] = useState<Checklist | null>(null);

    const openChecklist = (checklist: Checklist) => {
        setActiveChecklist(JSON.parse(JSON.stringify(checklist))); // Deep copy to avoid direct state mutation
        setViewModalOpen(true);
    };

    const handleChecklistItem = (itemIndex: number, checked: boolean) => {
        if (activeChecklist) {
            const updatedItems = [...activeChecklist.items];
            updatedItems[itemIndex].completed = checked;
            setActiveChecklist({ ...activeChecklist, items: updatedItems });
        }
    };
    
    const saveChecklistCompletion = () => {
        if (activeChecklist) {
            const allItemsCompleted = activeChecklist.items.every(item => item.completed);
            if (!allItemsCompleted) {
                alert("Please complete all items before submitting.");
                return;
            }

            const updatedChecklist = {
                ...activeChecklist,
                dateCompleted: new Date().toISOString(),
                completedBy: "Vendor", // In a real app, this would be the logged-in user
            };

            const newChecklists = checklists.map(c => c.id === updatedChecklist.id ? updatedChecklist : c);
            
            // Check if a new instance of the template needs to be created
            const originalTemplate = checklists.find(c => c.id === activeChecklist.id && c.createdBy === 'template');
            const completedInstanceExists = checklists.some(c => c.title === activeChecklist.title && c.dateCompleted);

            if (originalTemplate && !completedInstanceExists) {
                 const newInstance: Checklist = {
                     ...originalTemplate,
                     id: `CHK-${Date.now()}`,
                     items: originalTemplate.items.map(item => ({...item, completed: false })),
                     dateCompleted: undefined,
                     completedBy: undefined,
                 };
                 newChecklists.push(newInstance);
            }
            
            setChecklists(newChecklists);

            setViewModalOpen(false);
            setActiveChecklist(null);
        }
    };
    
    const pendingChecklists = checklists.filter(c => !c.dateCompleted);
    const completedChecklists = checklists.filter(c => c.dateCompleted);

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">Vendor Safety Checklists</h1>
            </div>
            
            <Card title="Pending Checklists">
                {pendingChecklists.length > 0 ? (
                    <div className="checklist-list">
                        {pendingChecklists.map(c => (
                            <div key={c.id} className="checklist-item">
                                <p className="checklist-title">{c.title}</p>
                                <Button size="sm" onClick={() => openChecklist(c)}>Start</Button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="empty-state">All checklists are complete!</p>
                )}
            </Card>

            <Card title="Completed Checklists">
                 {completedChecklists.length > 0 ? (
                    <div className="checklist-list">
                        {completedChecklists.map(c => (
                            <div key={c.id} className="checklist-item completed">
                                <div>
                                    <p className="checklist-title">{c.title}</p>
                                    <p className="completion-date">Completed on {new Date(c.dateCompleted!).toLocaleDateString()}</p>
                                </div>
                                <span className="completed-badge">Done</span>
                            </div>
                        ))}
                    </div>
                ) : (
                     <p className="empty-state">No checklists have been completed yet.</p>
                )}
            </Card>

            {activeChecklist && (
                <Modal isOpen={isViewModalOpen} onClose={() => setViewModalOpen(false)} title={activeChecklist.title}>
                    <div className="checklist-modal-body">
                        {activeChecklist.items.map((item, index) => (
                            <label key={index} className="checkbox-item">
                                <input 
                                    type="checkbox" 
                                    checked={item.completed}
                                    onChange={(e) => handleChecklistItem(index, e.target.checked)}
                                    className="checkbox-input"
                                />
                                <span className="checkbox-label">{item.text}</span>
                            </label>
                        ))}
                    </div>
                    <div className="modal-actions">
                        <Button onClick={saveChecklistCompletion} variant="primary">Mark as Complete</Button>
                    </div>
                </Modal>
            )}
        </div>
    );
};


export default ChecklistPage;