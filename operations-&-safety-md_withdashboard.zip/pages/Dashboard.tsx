import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';
import { ReportStatus } from '../types';
import { PlusIcon, ClipboardCheckIcon, ExclamationTriangleIcon, DocumentTextIcon, ShieldCheckIcon } from '../components/Icons';
import { useAppContext } from '../context/AppContext';
import './Dashboard.css';

const DashboardStat: React.FC<{ icon: React.ReactNode; label: string; value: string | number; colorClass: string }> = ({ icon, label, value, colorClass }) => (
    <div className="dashboard-stat">
        <div className={`stat-icon-wrapper ${colorClass}`}>
            {icon}
        </div>
        <div className="stat-content">
            <p className="stat-label">{label}</p>
            <p className="stat-value">{value}</p>
        </div>
    </div>
);

const Dashboard: React.FC = () => {
    const { incidents, checklists, documents } = useAppContext();

    const openIncidents = incidents.filter(i => i.status !== ReportStatus.Resolved).length;
    const pendingChecklists = checklists.filter(c => !c.dateCompleted).length;

    return (
        <div className="dashboard-container">
            <div className="dashboard-header">
                <div>
                    <h1 className="page-title">Welcome to Operations & Safety MD</h1>
                    <p className="page-subtitle">Your dashboard at a glance.</p>
                </div>
                <div className="header-actions">
                     <Link to="/report">
                        <Button variant="primary" leftIcon={<PlusIcon className="h-5 w-5"/>}>New Report</Button>
                    </Link>
                </div>
            </div>

            <div className="stats-grid">
                <DashboardStat icon={<ExclamationTriangleIcon className="h-6 w-6" />} label="Open Incidents" value={openIncidents} colorClass="bg-rose" />
                <DashboardStat icon={<ClipboardCheckIcon className="h-6 w-6" />} label="Pending Checklists" value={pendingChecklists} colorClass="bg-amber" />
                <DashboardStat icon={<DocumentTextIcon className="h-6 w-6" />} label="Safety Documents" value={documents.length} colorClass="bg-sky" />
            </div>

            <Card title="Quick Actions">
                <div className="quick-actions-grid">
                    <Link to="/report" className="quick-action-item bg-sky-light">
                        <ExclamationTriangleIcon className="quick-action-icon text-sky" />
                        <p className="quick-action-label">Report Incident</p>
                    </Link>
                    <Link to="/checklists" className="quick-action-item bg-emerald-light">
                        <ClipboardCheckIcon className="quick-action-icon text-emerald" />
                        <p className="quick-action-label">Start Checklist</p>
                    </Link>
                    <Link to="/risks" className="quick-action-item bg-amber-light">
                        <ShieldCheckIcon className="quick-action-icon text-amber" />
                        <p className="quick-action-label">Assess Risk</p>
                    </Link>
                    <Link to="/documents" className="quick-action-item bg-slate-light">
                        <DocumentTextIcon className="quick-action-icon text-slate" />
                        <p className="quick-action-label">View Documents</p>
                    </Link>
                </div>
            </Card>

            <Card title="Recent Incidents">
                <div className="recent-incidents-list">
                    {incidents.length > 0 ? (
                        incidents.slice(0, 3).map(incident => {
                            let statusClass = '';
                            switch(incident.status) {
                                case ReportStatus.Resolved: statusClass = 'status-resolved'; break;
                                case ReportStatus.Assessed: statusClass = 'status-assessed'; break;
                                default: statusClass = 'status-reported';
                            }
                            return (
                                <div key={incident.id} className="incident-item">
                                    <div>
                                        <p className="incident-description">{incident.title}: <span>{incident.description.substring(0, 50)}...</span></p>
                                        <p className="incident-date">{new Date(incident.date).toLocaleDateString()}</p>
                                    </div>
                                    <span className={`status-badge ${statusClass}`}>
                                        {incident.status}
                                    </span>
                                </div>
                            )
                        })
                    ) : (
                        <p className="empty-state-text">No incidents reported yet.</p>
                    )}
                </div>
                 {incidents.length > 3 && (
                    <div className="view-all-link">
                        <Link to="/risks">
                            <Button variant="ghost">View All Incidents</Button>
                        </Link>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default Dashboard;