import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Role } from '../types';
import Card from '../components/Card';
import Button from '../components/Button';
import { ShieldCheckIcon } from '../components/Icons';
import './Login.css';

const Login: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<Role>('user');
  const { login } = useAuth();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(selectedRole);
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <div className="login-header">
          <ShieldCheckIcon className="login-icon" />
          <h1 className="login-title">Operations & Safety MD</h1>
          <p className="login-subtitle">Please select your role to continue</p>
        </div>
        <Card>
          <form onSubmit={handleLogin} className="login-form">
            <div className="form-group">
              <label htmlFor="role-select">Select Role</label>
              <select
                id="role-select"
                className="form-select"
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as Role)}
              >
                <option value="user">Normal User</option>
                <option value="vendor">Vendor</option>
                <option value="supervisor">Supervisor</option>
              </select>
            </div>
            <Button type="submit" size="lg" className="login-button">
              Login
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Login;
