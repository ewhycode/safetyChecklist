import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Modal from '../components/Modal';
import RiskMatrix from '../components/RiskMatrix';
import { useAppContext } from '../context/AppContext';
import { IncidentReport, RiskAssessment, ReportStatus, RiskLevel } from '../types';
import './RiskAssessments.css';

const getStatusClass = (status: ReportStatus): string => {
    switch (status) {
        case ReportStatus.Reported: return 'status-reported';
        case ReportStatus.Assessed: return 'status-assessed';
        case ReportStatus.Resolved: return 'status-resolved';
        default: return '';
    }
};

const RiskAssessmentsPage: React.FC = () => {
    const { incidents, assessments, saveAssessment, resolveIncident } = useAppContext();
    const [isModalOpen, setModalOpen] = useState(false);
    const [selectedIncident, setSelectedIncident] = useState<IncidentReport | null>(null);

    const openAssessmentModal = (incident: IncidentReport) => {
        setSelectedIncident(incident);
        setModalOpen(true);
    };

    const handleSaveAssessment = (assessment: RiskAssessment) => {
        saveAssessment(assessment);
        setModalOpen(false);
        setSelectedIncident(null);
    };

    const handleResolveIncident = (incidentId: string) => {
        resolveIncident(incidentId);
    };

    const findAssessment = (incidentId: string) => assessments.find(a => a.incidentId === incidentId);

    return (
        <div className="page-container">
            <h1 className="page-title">Incident Risk Assessments</h1>
            <Card title="All Reported Incidents">
                {incidents.length > 0 ? (
                    <div className="incident-list">
                        {incidents.map(incident => {
                            const assessment = findAssessment(incident.id);
                            return (
                                <div key={incident.id} className="incident-item">
                                    <div className="incident-details">
                                        <p className="incident-location">{incident.title}: <span>{incident.location}</span></p>
                                        <p className="incident-description">{incident.description}</p>
                                        <p className="incident-date">Reported on: {new Date(incident.date).toLocaleString()}</p>
                                    </div>
                                    <div className="incident-actions">
                                        <span className={`status-badge ${getStatusClass(incident.status)}`}>{incident.status}</span>
                                        {incident.status !== ReportStatus.Resolved && (
                                            <>
                                                <Button size="sm" variant="secondary" onClick={() => openAssessmentModal(incident)}>
                                                    {assessment ? 'View/Edit' : 'Assess'}
                                                </Button>
                                                {incident.status === ReportStatus.Assessed && (
                                                    <Button size="sm" variant="primary" onClick={() => handleResolveIncident(incident.id)}>Resolve</Button>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <p className="empty-state">No incidents to assess.</p>
                )}
            </Card>

            {selectedIncident && (
                <AssessmentModal
                    isOpen={isModalOpen}
                    onClose={() => setModalOpen(false)}
                    incident={selectedIncident}
                    existingAssessment={findAssessment(selectedIncident.id)}
                    onSave={handleSaveAssessment}
                />
            )}
        </div>
    );
};

interface AssessmentModalProps {
    isOpen: boolean;
    onClose: () => void;
    incident: IncidentReport;
    existingAssessment?: RiskAssessment;
    onSave: (assessment: RiskAssessment) => void;
}

const AssessmentModal: React.FC<AssessmentModalProps> = ({ isOpen, onClose, incident, existingAssessment, onSave }) => {
    const [likelihood, setLikelihood] = useState(existingAssessment?.likelihood || 0);
    const [consequence, setConsequence] = useState(existingAssessment?.consequence || 0);
    const [mitigationSteps, setMitigationSteps] = useState(existingAssessment?.mitigationSteps || '');

    const getRiskLevel = (l: number, c: number): RiskLevel => {
        const score = (l + 1) * (c + 1);
        if (score <= 4) return RiskLevel.Low;
        if (score <= 9) return RiskLevel.Medium;
        if (score <= 15) return RiskLevel.High;
        return RiskLevel.Extreme;
    };

    const handleSave = () => {
        if (!mitigationSteps) {
            alert("Please provide mitigation steps.");
            return;
        }
        const newAssessment: RiskAssessment = {
            id: existingAssessment?.id || `RA-${Date.now()}`,
            incidentId: incident.id,
            likelihood,
            consequence,
            riskLevel: getRiskLevel(likelihood, consequence),
            mitigationSteps,
            assessmentDate: new Date().toISOString(),
        };
        onSave(newAssessment);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Assess Incident: ${incident.id}`}>
            <div className="assessment-modal-content">
                <div className="assessment-section">
                    <h4 className="assessment-section-title">Incident Details</h4>
                    <p className="incident-details-box">{incident.description}</p>
                    {incident.photo && <img src={incident.photo} alt="Incident" className="incident-photo-preview" />}
                </div>
                <div className="assessment-section">
                    <h4 className="assessment-section-title">Risk Matrix</h4>
                    <RiskMatrix 
                        likelihood={likelihood}
                        consequence={consequence}
                        onRiskChange={(l, c) => { setLikelihood(l); setConsequence(c); }}
                    />
                </div>
                <div className="assessment-section">
                     <label htmlFor="mitigation" className="form-label">Mitigation Steps</label>
                      <textarea
                        id="mitigation"
                        rows={4}
                        value={mitigationSteps}
                        onChange={(e) => setMitigationSteps(e.target.value)}
                        placeholder="Document the actions taken or planned to mitigate this risk..."
                        className="form-textarea"
                        required
                    />
                </div>
                <div className="modal-actions">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button variant="primary" onClick={handleSave}>Save Assessment</Button>
                </div>
            </div>
        </Modal>
    );
};

export default RiskAssessmentsPage;