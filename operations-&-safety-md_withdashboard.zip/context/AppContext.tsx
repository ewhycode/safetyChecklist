import React, { createContext, useContext } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { 
    IncidentReport, 
    Checklist,
    RiskAssessment,
    SafetyDocument,
    LostPropertyReport,
    ReportStatus
} from '../types';


// --- Initial Data --- //
const initialChecklists: Checklist[] = [
    {
        id: 'CHK-VENDOR-1',
        title: 'Vendor Stall Opening Checklist',
        createdBy: 'template',
        items: [
            { text: 'All electrical cords are secured and not a trip hazard', completed: false },
            { text: 'Fire extinguisher is accessible and has been checked', completed: false },
            { text: 'Food items are stored at correct temperatures', completed: false },
            { text: 'All staff are wearing appropriate safety gear (e.g., aprons, non-slip shoes)', completed: false },
            { text: 'Emergency exit path from stall is clear', completed: false },
        ]
    },
    {
        id: 'CHK-VENDOR-2',
        title: 'Vendor Stall Closing Checklist',
        createdBy: 'template',
        items: [
            { text: 'All gas appliances have been turned off', completed: false },
            { text: 'Perishable goods stored correctly', completed: false },
            { text: 'Waste and recycling disposed of in designated bins', completed: false },
            { text: 'Stall area is clean and tidy', completed: false },
        ]
    }
];

const initialDocuments: SafetyDocument[] = [
    { id: 'DOC-2', name: 'Public Liability Insurance Certificate.pdf', fileType: 'application/pdf', uploadDate: new Date('2023-09-01').toISOString() },
    { id: 'DOC-3', name: 'Emergency Evacuation Plan.docx', fileType: 'application/msword', uploadDate: new Date('2023-05-20').toISOString() },
    { id: 'DOC-4', name: 'First Aid Officer Certificates.zip', fileType: 'application/zip', uploadDate: new Date('2023-11-01').toISOString() },
];

interface AppContextType {
    incidents: IncidentReport[];
    addIncident: (incident: Omit<IncidentReport, 'id' | 'date' | 'status'>) => void;
    updateIncidentStatus: (incidentId: string, status: ReportStatus, riskAssessmentId?: string) => void;
    resolveIncident: (incidentId: string) => void;

    checklists: Checklist[];
    setChecklists: (checklists: Checklist[]) => void;
    
    assessments: RiskAssessment[];
    saveAssessment: (assessment: RiskAssessment) => void;
    
    documents: SafetyDocument[];
    addDocument: (file: File) => void;
    deleteDocument: (docId: string) => void;

    lostProperty: LostPropertyReport[];
    addLostProperty: (report: Omit<LostPropertyReport, 'id' | 'date'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [incidents, setIncidents] = useLocalStorage<IncidentReport[]>('incidents', []);
    const [checklists, setChecklists] = useLocalStorage<Checklist[]>('checklists', initialChecklists);
    const [assessments, setAssessments] = useLocalStorage<RiskAssessment[]>('assessments', []);
    const [documents, setDocuments] = useLocalStorage<SafetyDocument[]>('documents', initialDocuments);
    const [lostProperty, setLostProperty] = useLocalStorage<LostPropertyReport[]>('lostProperty', []);

    const addIncident = (incident: Omit<IncidentReport, 'id' | 'date' | 'status'>) => {
        const newIncident: IncidentReport = {
            ...incident,
            id: `INC-${Date.now()}`,
            date: new Date().toISOString(),
            status: ReportStatus.Reported,
        };
        setIncidents(prev => [newIncident, ...prev]);
    };

    const updateIncidentStatus = (incidentId: string, status: ReportStatus, riskAssessmentId?: string) => {
        setIncidents(prev => prev.map(inc => 
            inc.id === incidentId ? { ...inc, status, riskAssessmentId } : inc
        ));
    };
    
    const resolveIncident = (incidentId: string) => {
        updateIncidentStatus(incidentId, ReportStatus.Resolved);
    };

    const saveAssessment = (assessment: RiskAssessment) => {
        setAssessments(prev => [...prev.filter(a => a.incidentId !== assessment.incidentId), assessment]);
        updateIncidentStatus(assessment.incidentId, ReportStatus.Assessed, assessment.id);
    };

    const addDocument = (file: File) => {
        const newDocument: SafetyDocument = {
            id: `DOC-${Date.now()}`,
            name: file.name,
            fileType: file.type,
            uploadDate: new Date().toISOString(),
        };
        setDocuments(prev => [newDocument, ...prev]);
    };

    const deleteDocument = (docId: string) => {
        setDocuments(docs => docs.filter(d => d.id !== docId));
    };

    const addLostProperty = (report: Omit<LostPropertyReport, 'id' | 'date'>) => {
        const newReport: LostPropertyReport = {
            ...report,
            id: `LP-${Date.now()}`,
            date: new Date().toISOString(),
        };
        setLostProperty(prev => [newReport, ...prev]);
    };


    return (
        <AppContext.Provider value={{ 
            incidents, addIncident, updateIncidentStatus, resolveIncident,
            checklists, setChecklists,
            assessments, saveAssessment,
            documents, addDocument, deleteDocument,
            lostProperty, addLostProperty
        }}>
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};
