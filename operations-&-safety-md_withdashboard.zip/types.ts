
export type Role = 'supervisor' | 'vendor' | 'user';

export interface User {
  name: string;
  role: Role;
}

export enum ReportStatus {
  Reported = 'Reported',
  Assessed = 'Assessed',
  Resolved = 'Resolved',
}

export interface IncidentReport {
  id: string;
  title: string;
  description: string;
  photo?: string; // base64 string
  location: string;
  date: string;
  status: ReportStatus;
  riskAssessmentId?: string;
}

export interface LostPropertyReport {
  id: string;
  itemName: string;
  description: string;
  location: string;
  date: string;
  contactDetails: string;
}

export interface Checklist {
  id: string;
  title: string;
  createdBy: 'template' | 'user' | 'ai';
  items: { text: string; completed: boolean }[];
  dateCompleted?: string;
  completedBy?: string;
}

export enum RiskLevel {
    Low = 'Low',
    Medium = 'Medium',
    High = 'High',
    Extreme = 'Extreme',
    Unknown = 'Unknown',
}

export interface RiskAssessment {
  id: string;
  incidentId: string;
  likelihood: number; // 1-5
  consequence: number; // 1-5
  riskLevel: RiskLevel;
  mitigationSteps: string;
  assessmentDate: string;
}

export interface SafetyDocument {
  id: string;
  name: string;
  fileType: string;
  uploadDate: string;
  fileData?: string;
}